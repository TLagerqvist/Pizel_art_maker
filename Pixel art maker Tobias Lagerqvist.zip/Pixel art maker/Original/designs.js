// Select color input
// Select size input

// When size is submitted by the user, call makeGrid()

function makeGrid() {

// Your code goes here!
document.getElementById("sizePicker").addEventListener("click", function() {
event.preventDefault();
});

const baseElement = document.createElement('div');
baseElement.style.cssText = 'width: auto; position: relative; right: -50%; float: left'; 
//creates non visable base for boxes

const submitForm = document.getElementById("sizePicker");
const submitIndex = submitForm[2];
//Accesses the submit button

submitIndex.addEventListener("click", function() {

    const squareXY = function() {
    const inputValueY = parseInt(inputHeight.value);
    const inputValueX = parseInt(inputWidth.value);

    if(inputValueY > 38 && inputValueX > 38 || (inputValueY > 38 || inputValueX > 38)) {
        inputHeight.style.backgroundColor = "pink";
        inputWidth.style.backgroundColor = "pink";
    }

    else { //{Else ANGLE BRACKET
        inputHeight.style.backgroundColor = "white";
        inputWidth.style.backgroundColor = "white";

    for (let j = 1; j <= parseInt(inputHeight.value); j++) {

        const newSquareY = document.createElement('div');
        newSquareY.style.cssText = 'width: 30px; height: 30px; border-color: black; border-width: 1px; border-style: dotted; background-color: white; float: none; position: relative; left: -50%;';

    newSquareY.className = "purpleBoxes"; //(The boxes where purple during testing hence the name)
    baseElement.appendChild(newSquareY);
  
    {
    for (let i = 1; i <= parseInt(inputWidth.value); i++) {
        const newSquareX = document.createElement('div');
        newSquareX.style.cssText = 'width: 30px; height: 30px; border-color: black; border-width: 1px; border-style: dotted;  background-color: white; float: left; position: relative; left: -50%;';    
        newSquareX.className = "purpleBoxes"; //(The boxes where purple during testing hence the name)
        baseElement.insertBefore(newSquareX, newSquareY);
        }
    }
    }
}

document.body.appendChild(baseElement); //Appends base div with x * y amount of boxes

} //Else ANGLE BRACKET


function removeElementsByClass(className) {
    const boxes = document.getElementsByClassName(className);
    
    while(boxes.length > 0) {
        boxes[0].parentElement.removeChild(boxes[0]);
    }
}

removeElementsByClass("purpleBoxes");
// Removes excisting boxes to make room for new grid


baseElement.addEventListener("click", function (event) {
let toChange = event.target;
let chooseColor = document.getElementById("colorPicker").value;

    if(event.target.className === 'purpleBoxes') {
    toChange.style.backgroundColor = chooseColor;
    } 
});

squareXY();
});

}

makeGrid();